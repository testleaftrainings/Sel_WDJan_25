package testcase;

import base.BaseClass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="src/main/java/features", glue="pages",monochrome = true,publish=true,tags="@Regression or @Sanity")
public class RunnerClass extends BaseClass{

}



//TestNG - Execute XML
//Cucumber - Runner Class - driver->Static

//PageObjectModel:
//Sequential- driver-> static
//Parallel-  Constructor config driver-Non Static

//PageObjectModel with cucumber -ThreadLocal Implementation
//ThreadLocal - Encapsulation