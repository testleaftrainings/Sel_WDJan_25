package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyHomePage extends BaseClass {
	                  
	
	@When("Click on Leads link")
	public MyLeadsPage clickOnLeadsButton() {
		String propertyOfClickLeads = prop.getProperty("clickLeads");
		getDriver().findElement(By.linkText(propertyOfClickLeads)).click();
          return new MyLeadsPage();
	}

}
