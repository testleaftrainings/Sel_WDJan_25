package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	
	public static Properties prop;
	
	public void setDriver() {
		cDriver.set(new ChromeDriver());

	}
	
	public ChromeDriver getDriver() {
		ChromeDriver chromeDriver = cDriver.get();
		return chromeDriver;

	}
	
	
	//ChromeDriver driver=new ChromeDriver();
	//public static ChromeDriver driver;
	public String filename;
	@BeforeMethod
	public void preConditions() throws IOException {
		
		        //Step1: Locate the file using the path
				FileInputStream fis=new FileInputStream("src/main/resources/en.properties");
		  
				//Step2:Load the file
				prop=new Properties();
				
				//Step3: Pass the file to the Property class
				
				prop.load(fis);
		
				setDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/control/main");

	}
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);

	}

}
