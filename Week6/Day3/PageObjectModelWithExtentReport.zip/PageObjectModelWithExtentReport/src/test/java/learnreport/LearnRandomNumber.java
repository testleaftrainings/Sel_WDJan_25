package learnreport;

public class LearnRandomNumber {
	public static void main(String[] args) {
		//double random = Math.random();
		//System.out.println((random*99999999));
		
		int random=(int)(Math.random()*999999999+999999999);
		System.out.println(random);
	}

}

//0.6717191395384668*999999999999999999
//0.3698488554103042


//6+9999
//1950198069
//1458916451