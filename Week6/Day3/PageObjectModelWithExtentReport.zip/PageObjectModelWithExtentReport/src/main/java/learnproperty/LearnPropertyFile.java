package learnproperty;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnPropertyFile {

	public static void main(String[] args) throws IOException {
		//Step1: Locate the file using the path
		FileInputStream fis=new FileInputStream("src/main/resources/fr.properties");
  
		//Step2:Load the file
		Properties prop=new Properties();
		
		//Step3: Pass the file to the Property class
		prop.load(fis);
		
		//To Retrieve
		String propertyOfUsername = prop.getProperty("username");
		System.out.println(propertyOfUsername);
		
	}

}
