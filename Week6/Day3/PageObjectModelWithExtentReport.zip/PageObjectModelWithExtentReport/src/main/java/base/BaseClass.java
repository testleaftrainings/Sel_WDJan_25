package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	
	public static Properties prop;
	
	public static ExtentReports extent;
	
	public static ExtentTest test;
	
	public  static String testName,testDescription,testAuthor,testCategory;
	
	public void setDriver() {
		cDriver.set(new ChromeDriver());

	}
	
	public ChromeDriver getDriver() {
		ChromeDriver chromeDriver = cDriver.get();
		return chromeDriver;

	}
	
	@BeforeSuite
	public void startReport() {
		//Step1: Set up the path for the report
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/loginpage.html");
		
		//Step2: Create an Test
		extent=new ExtentReports();
		
		//Step3: Adding the test to the report
		extent.attachReporter(reporter);

	}
	
	@BeforeClass
	public void testCaseDetails() {
		test = extent.createTest(testName ,testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	
	//ChromeDriver driver=new ChromeDriver();
	//public static ChromeDriver driver;
	public String filename;
	@BeforeMethod
	public void preConditions() throws IOException {
		
		        //Step1: Locate the file using the path
				FileInputStream fis=new FileInputStream("src/main/resources/en.properties");
		  
				//Step2:Load the file
				prop=new Properties();
				
				//Step3: Pass the file to the Property class
				
				prop.load(fis);
		
				setDriver();
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		getDriver().get("http://leaftaps.com/opentaps/control/main");

	}
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);

	}
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	
	
	
	public void reportStep(String status, String message) throws IOException {
		if (status.equalsIgnoreCase("Pass")) {
			test.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
		}
		
		if (status.equalsIgnoreCase("Fail")) {
			test.fail(message, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
		}
		


	}
	public int takeSnap() throws IOException {
		int random=(int)(Math.random()*999999999+999999999);
		File source = getDriver().getScreenshotAs(OutputType.FILE);

		File destination=new File("./Snaps/image"+random+".png");
		
		FileUtils.copyFile(source, destination);
		return random;
		
	}
	
	
	
	
	
	
	
	
	

}
