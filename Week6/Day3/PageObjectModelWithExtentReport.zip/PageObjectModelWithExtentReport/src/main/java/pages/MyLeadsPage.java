package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyLeadsPage extends BaseClass {
	
	
	@When("Click on CreateLead link")
	public CreateLeadPage clickOnCreateLeadLink() {
		String propertyOfClickCreateLead = prop.getProperty("clickCreateLead");
		getDriver().findElement(By.partialLinkText(propertyOfClickCreateLead)).click();
        return new CreateLeadPage();
	}

}
