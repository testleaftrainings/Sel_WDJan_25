package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.WelcomePage;

public class CreateLeadFunctionality extends BaseClass {
	
	@BeforeTest
	public void setValue() {
	 filename="CreateLead";

	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String username, String password, String companyname, String firstname,String lastname) {
		LoginPage lp=new LoginPage(driver);
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCRMSFALink()
		.clickOnLeadsButton()
		.clickOnCreateLeadLink()
		.enterCompanyname(companyname)
		.enterFirstname(firstname)
		.enterLastName(lastname)
		.clickCreateLeadButton()
		.verifyLead();
			
		
	}
	

}
