package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass{
	
	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	@When("Enter the companyname as (.*)$")
	public CreateLeadPage enterCompanyname(String companyname) {
		
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyname);
	      return this;
	}
	@When("Enter the firstname as (.*)$")
	public CreateLeadPage enterFirstname(String firstname) {
		 driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
         return this;
	}
	@When("Enter the lastname as (.*)$")
	public CreateLeadPage enterLastName(String lastname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
          return this;
	}
	
	@When("Click on Create Lead button")
	public ViewLeadPage clickCreateLeadButton() {
		driver.findElement(By.name("submitButton")).click();
        return new ViewLeadPage(driver);
	}

}
