package pages;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {
	
	public void verifyLead() {
		System.out.println("Lead is created");

	}
	
	

}
