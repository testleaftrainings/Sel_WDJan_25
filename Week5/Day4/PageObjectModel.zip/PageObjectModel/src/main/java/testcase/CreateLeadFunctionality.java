package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.WelcomePage;

public class CreateLeadFunctionality extends BaseClass {
	
	@Test
	public void runCreateLead() {
		LoginPage lp=new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCRMSFALink()
		.clickOnLeadsButton()
		.clickOnCreateLeadLink()
		.enterCompanyname()
		.enterFirstname()
		.enterLastName()
		.clickCreateLeadButton()
		.verifyLead();
			
		
	}
	

}
