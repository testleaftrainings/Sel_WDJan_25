package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class LogoutFunctionality extends BaseClass {
	
	@Test
	public void runLogout() {
		LoginPage lp=new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLogout();

	}

}
